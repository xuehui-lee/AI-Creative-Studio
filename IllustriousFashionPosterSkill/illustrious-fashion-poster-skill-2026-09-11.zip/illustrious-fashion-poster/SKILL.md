---
name: illustrious-fashion-poster
description: 为 Illustrious 系模型生成、反推、修改或精简二次元女性时尚杂志海报 Prompt；默认严格使用用户指定的固定模块、顺序和长度，不自动扩写。
metadata:
  short-description: Illustrious 二次元时尚海报提示词
---

# Illustrious 二次元女性时尚海报 Prompt

根据用户提供的自然语言、参考图或旧 Prompt，生成可直接用于 Illustrious 系模型的英文逗号标签提示词。

## 最高优先级：固定输出契约

除非用户明确提出特殊修改，否则必须严格遵守本文件中的固定词、模块顺序和简洁程度。

- 默认输出一份完整英文正向 Prompt，并紧随一份中文翻译；两者分别放在代码块中，每个内容模块单独占一行。
- 不默认输出 Standard / Compact / Negative / 中文解析四段结构。
- 只有用户明确要求时，才额外输出 Negative Prompt、解析、多个版本或参数建议。
- 不因“优化”“专业化”“提高质量”等笼统要求增加新模块、摄影词、渲染词或同义词。
- 用户局部修改角色、服装、姿态、表情、色调或拍摄角度后，重新输出合并完成的整条 Prompt；不要只给替换片段。
- 用户明确要求打破固定项时，以该次要求为准；未明确指定的固定项保持原样。

### 永久格式与长度约束

以下规则适用于生成、反推、优化、精简、换角色、换装、换姿态以及连续多轮修改：

- 无论修改多少次，11 个模块的顺序和固定部分都不得改变。
- 英文 Prompt 必须固定为 11 个非空内容行，每个模块结束后立即换行；模块内部不换行，模块之间不插入空行。
- 中文翻译必须同样固定为 11 个非空内容行，并与英文 Prompt 的模块逐行对应。
- 每次修改必须在对应变量槽位中“删除旧值并写入新值”，禁止把新标签追加到旧标签后面。
- 默认不得让 Prompt 越改越长。若用户只替换内容，修改后的变量模块应与修改前保持相近长度或更短。
- 用户新增一个明确特征时，只在对应变量模块增加必要标签；同时删除被覆盖、重复或不再适用的旧标签。
- 不使用同义词堆叠来强化概念，不为显得专业而补充用户未要求的细节。
- 不把冲突检查、人体逻辑、设计分析或自然语言解释写进 Prompt。
- 固定模块逐字复用；变量模块保持短标签表达，不改成长句。
- 即使用户只修改一个局部，也要输出相同格式的完整 Prompt，但不得重写或扩充其他模块。
- 除非用户明确指定额外输出，否则回复中只保留“英文 Prompt”和“中文翻译”两个代码块，不附带解析、修改说明或第二版本。
- “不得越改越长”只约束英文 Prompt；中文翻译是对应译文，不属于模型提示词。

变量模块默认密度上限：

```text
角色与作品：2 个标签
发型与瞳色：2–5 个标签
表情神态：2–4 个标签
服饰穿搭：6–12 个标签
基础姿态：4–8 个标签
背景：严格 7 个标签
构图：严格 4 个标签
```

以上数量是防止堆砌的默认上限。只有用户明确要求增加具体内容时才可突破，并且固定格式仍然不变。

### 中文翻译规则

- 中文翻译必须与英文 Prompt 使用完全相同的模块顺序。
- 逐项翻译英文标签，不新增、删减、概括或解释任何画面信息。
- 每个模块内部使用中文逗号连续书写；每个内容模块结束后换行，共 11 个非空内容行，不插入空行。
- 角色名和作品名使用通行中文名；没有可靠中文名时保留原文。
- 权重、数字和明确的技术含义必须保留，例如 `1.1`、`2.5D`。
- 中文翻译仅帮助用户阅读，不替代英文 Prompt，不反向扩写英文内容。

默认回复格式固定为：

```markdown
英文 Prompt

`英文提示词代码块`

中文翻译

`中文译文代码块`
```

## 固定模块与顺序

必须依照以下顺序编排。每个模块单独占一行，共 11 个非空内容行。模块内部使用英文逗号和空格连接；除最后一行外，每行末尾保留英文逗号。代码块内部不添加模块标题、编号或空行。

### 1. 画质：完全固定

必须原样使用，不增加或删除标签：

```text
masterpiece, best quality, amazing quality, very aesthetic, absurdres
```

不得自动加入 `newest`、`impactful picture` 或其他画质词。

### 2. 主体身材：完全固定

必须原样使用：

```text
1girl, solo, 20 years old, pale skin, slim body, slender, petite frame, narrow hips, slender waist, long slender legs, balanced slim legs, natural slim thighs
```

不得自动加入 `adult woman`、`curvy`、`mature female`、胸围或其他体型词。即使角色原作年龄或体型不同，也不得自行修改这段；只有用户明确要求时才改变。

### 3. 角色与作品：变量，格式固定

格式：

```text
<character name>, <series name>
```

示例：

```text
illyasviel von einzbern, fate/kaleid liner prisma illya
```

- 角色名在前，作品名在后，各出现一次。
- 默认使用模型常见的英文或罗马字名称。
- 不自动使用括号、下划线、canonical tag 分组或角色权重。

### 4. 外貌、视线与表情

固定结构：

```text
<hair and eye traits>, looking at viewer, <expression traits>, soft lips, elegant face
```

其中：

- 发色、发长、发型、瞳色是变量。
- `looking at viewer` 完全固定。
- 表情神态是变量，保持与示例相近的简洁程度，通常使用 2–4 个基础标签。
- `soft lips, elegant face` 完全固定并置于本模块末尾。
- 不自动增加 `direct eye contact`；只有用户明确要求或原 Prompt 明确保留时才使用。

### 5. 服饰穿搭：变量

使用简洁、直接的服装标签，按以下逻辑排列：

```text
上装或连衣装 → 版型或材质 → 袖型 → 袜装 → 鞋履 → 首饰与配件
```

- 保持与用户示例相近的描述密度，给模型保留发挥空间。
- 不自动展开领口、缝线、面料反光、褶皱、刺绣等微观细节。
- 用户给出的近义服装标签可按原风格保留，不以“优化”为由扩写成更长描述。

### 6. 姿态

必须以以下两个固定标签开头：

```text
full body, fashion model pose
```

之后接姿态变量，仅描述基础动作关系，例如：

```text
standing, playful standing pose, v sign, hand near face, narrow leg stance, one thin leg forward, knees close together
```

- 默认使用约 4–8 个基础动作标签。
- 只说明站、坐、跪、运动状态，以及必要的手、腿和身体方向。
- 不自动加入重心分析、肌肉发力、衣物动态、复杂肢体闭环或长句摄影描述。
- 动作存在明显互斥时，静默删除被新要求覆盖的旧姿态标签。

### 7. 杂志封面：完全固定

必须原样使用：

```text
(Japanese fashion magazine cover:1.1), haute couture campaign, luxury fashion editorial, minimalist editorial design, oversized serif masthead, small editorial text blocks, clean typography layout, strong negative space
```

不得改成整组加权，不得把权重改为 `1.2`，不得自动指定标题颜色。

### 8. 背景：结构固定，仅色调变量

固定结构：

```text
minimal geometric background, two-tone background, <base color> background, bold <accent color> diagonal stripe, <secondary color> floor shape, glossy <floor color> floor, subtle floor reflection
```

示例：

```text
minimal geometric background, two-tone background, off-white background, bold red diagonal stripe, desaturated blue-gray floor shape, glossy black floor, subtle floor reflection
```

- 只根据人物、服装或用户要求修改基础色、斜条色、地面图形色和地板色。
- 不自动增加场景、家具、道具、纹理、空间设计或环境特效。

### 9. 构图：角度变量，其余固定

固定结构：

```text
<shot angle>, dynamic perspective, long vertical composition, centered subject
```

拍摄角度是变量，例如：

```text
low-angle shot
eye-level shot
slightly high-angle shot
```

除拍摄角度外，不自动修改或扩写其他三个固定标签。

### 10. 灯光：完全固定

必须原样使用：

```text
professional studio lighting, soft rim light, bright white key light
```

### 11. 风格：完全固定

必须原样使用：

```text
semi-realistic anime, 2.5d anime illustration, smooth rendering, refined anatomy
```

不得自动增加画师名、游戏宣传图、电影渲染、景深、锐焦点或其他风格标签。

## 默认完整模板

```text
masterpiece, best quality, amazing quality, very aesthetic, absurdres,
1girl, solo, 20 years old, pale skin, slim body, slender, petite frame, narrow hips, slender waist, long slender legs, balanced slim legs, natural slim thighs,
<character name>, <series name>,
<hair and eye traits>, looking at viewer, <expression traits>, soft lips, elegant face,
<outfit traits>,
full body, fashion model pose, <basic pose traits>,
(Japanese fashion magazine cover:1.1), haute couture campaign, luxury fashion editorial, minimalist editorial design, oversized serif masthead, small editorial text blocks, clean typography layout, strong negative space,
minimal geometric background, two-tone background, <base color> background, bold <accent color> diagonal stripe, <secondary color> floor shape, glossy <floor color> floor, subtle floor reflection,
<shot angle>, dynamic perspective, long vertical composition, centered subject,
professional studio lighting, soft rim light, bright white key light,
semi-realistic anime, 2.5d anime illustration, smooth rendering, refined anatomy
```

## 参考图与旧 Prompt

- 参考图反推时，只提取角色、发型瞳色、表情、服装、姿态、背景色调和拍摄角度这些变量。
- 固定模块不根据参考图改变，除非用户明确要求。
- 旧 Prompt 修改时，只替换用户要求变化的变量，并清除该变量的旧内容；其他变量与所有固定项原样保留。
- 不复制参考图中的品牌、Logo、署名或水印。

## 静默检查

输出前仅检查以下事项，不向 Prompt 增加解释性标签：

1. 固定模块是否逐字保留且顺序正确。
2. 角色名与作品名是否各出现一次。
3. 新旧发型、瞳色、服装、姿态、表情和角度是否残留冲突。
4. 姿态是否没有同时出现站、坐、跪等互斥状态。
5. 背景是否只修改颜色，结构没有被扩写。
6. 英文 Prompt 是否简洁、可复制，并且没有因修改而无故增长。
7. 中文翻译是否与英文 Prompt 顺序一致、信息一一对应且没有额外扩写。
8. 英文 Prompt 和中文翻译是否都严格为 11 个非空内容行，且模块之间没有空行。
